WARNING (P2P-Streams)
================
For the old p2p-streams addon visit the [WIKI](https://github.com/enen92/Plexus/wiki)

Plexus
================
![](http://s23.postimg.org/fp6iz6y6z/plexusbanner.jpg)

**Plexus** - Any complex structure containing an intricate network of parts. Plexus brings native peer-to-peer support ([AceStream](http://www.acestream.org) and [SopCast](http://www.sopcast.org)) for [Kodi Entertainment Center](http://kodi.tv) for several platforms.

